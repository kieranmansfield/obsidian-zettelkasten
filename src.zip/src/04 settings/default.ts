import { NewZettelSettings } from "src/99 types/interfaces";

export const DEFAULT_NEWZETTEL_SETTINGS: NewZettelSettings = {
	matchRule: "separator",
	separator: " ",
	addTitle: true,
	addAlias: false,
	templateFile: "",
	templateRequireTitle: false,
	templateRequireLink: false,
	useLinkAlias: false,
};
