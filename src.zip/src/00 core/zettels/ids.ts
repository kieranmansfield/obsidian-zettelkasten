/* eslint-disable @typescript-eslint/no-explicit-any */
// import { segmentType } from "src/99 types/types";

export default function checkSegmentType(s: any) {
	return typeof s == "number" ? "numbers" : "letters";
}

// export default class ids {
// 	public checkSegmentType(s: segmentType): string {
// 		// const numberRegex: RegExp = /[0-9]/;
// 		// const isMatch: boolean = numberRegex.test(s);
// 		return typeof s == "number" ? "numbers" : "letters";
// 	}

// 	public idDepth(id: any) {
// 		const idCharacters = id.split("");
// 		let depth: number = 0;

// 		for (let i = 0; i <= idCharacters.length; i++) {
// 			if (
// 				i == 0 &&
// 				this.checkSegmentType(idCharacters[i]).includes("numbers")
// 			)
// 				return;

// 			if (this.checkSegmentType(idCharacters[i])) {
// 				depth++;
// 			}
// 		}
// 		return depth;
// 	}
// }
