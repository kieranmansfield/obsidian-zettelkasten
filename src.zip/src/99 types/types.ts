export type segmentType = "numbers" | "letters";
