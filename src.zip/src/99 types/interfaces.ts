export interface NewZettelSettings {
	matchRule: "strict" | "separator" | "fuzzy";
	separator: string;
	addTitle: boolean;
	addAlias: boolean;
	templateFile: string;
	templateRequireTitle: boolean;
	templateRequireLink: boolean;
	useLinkAlias: boolean;
}
